import React from 'react';
import "../header/Header.css"

function Header() {
    return (
        <div>
            <div className="container-fluaid">
                <div className="row py-1  " id='head'>
                    <div className="col-sm-12 col-md-6 text-white mt-2">
                      <div> <b><i>Title of a longer blogger featured blog post</i></b></div>
                        <p >Lorem  ipsa! Delectus suscipit laudantium inventore saepe, corrupti sint deserunt facilis provident.</p>
                       <p style={{color:"white",fontSize:"15px"}}>Continue reading....</p>
                    </div>
              
                </div>
            </div>
        </div>
    );
}

export default Header;