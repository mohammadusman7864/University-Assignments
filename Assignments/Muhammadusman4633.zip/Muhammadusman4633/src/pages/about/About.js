import React from 'react';           
import './About.css'


function About() {
    return (
        <div>
            <h1 style={{backgroundColor: 'red'}} className='text'>About Us</h1>
        </div>
    );
}

export default About;
